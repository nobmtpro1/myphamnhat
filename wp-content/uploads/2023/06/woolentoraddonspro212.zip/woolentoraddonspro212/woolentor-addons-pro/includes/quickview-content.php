<?php
/**
 * The template for displaying product content in the quickview-product.php template
 *
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

?>
<div class="woolentor-quickview-content-builder">
    <?php do_action( 'woolentor_quick_view_content' ); ?>
</div>