<?php
/**
 * Meta Boxes.
 */

namespace WLEA\Admin;

/**
 * Class.
 */
class Meta_Boxes {

	/**
     * Constructor.
     */
    public function __construct() {
        new Meta_Boxes\Workflows();
    }

}